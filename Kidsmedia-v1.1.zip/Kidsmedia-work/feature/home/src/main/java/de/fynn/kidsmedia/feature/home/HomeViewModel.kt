package de.fynn.kidsmedia.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.data.GetHomeFeedUseCase
import de.fynn.kidsmedia.core.model.Content
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val isLoading:  Boolean       = true,
    val featured:   List<Content> = emptyList(),
    val recentlyAdded: List<Content> = emptyList(),
    val continueWatching: List<Content> = emptyList(),
    val error:      String?       = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository:    ContentRepository,
    private val homeFeedUseCase: GetHomeFeedUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        observeContent()
        syncManifest()
    }

    private fun observeContent() {
        viewModelScope.launch {
            repository.observeAll().collect { allContent ->
                _uiState.update { state ->
                    state.copy(
                        isLoading        = false,
                        featured         = allContent.take(5),
                        recentlyAdded    = allContent.sortedByDescending { it.version }.take(10),
                        continueWatching = allContent.filter { it.progress > 0f && it.progress < 1f }
                    )
                }
            }
        }
    }

    private fun syncManifest() {
        viewModelScope.launch {
            runCatching { repository.syncManifest() }
                .onFailure { e ->
                    _uiState.update { it.copy(error = e.message) }
                }
        }
    }

    fun clearError() = _uiState.update { it.copy(error = null) }
}
