package de.fynn.kidsmedia.feature.downloads

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.ui.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    repository: ContentRepository
) : ViewModel() {
    val downloads: StateFlow<List<Content>> = repository.observeAll()
        .map { list -> list.filter { it.isDownloaded } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

@Composable
fun DownloadsScreen(
    onContentClick: (String) -> Unit,
    onBack:         () -> Unit,
    viewModel:      DownloadsViewModel = hiltViewModel()
) {
    val downloads by viewModel.downloads.collectAsState()

    Scaffold(
        topBar = { KidsMediaTopBar(title = "Downloads ✓", onBack = onBack) }
    ) { padding ->
        if (downloads.isEmpty()) {
            EmptyState(
                emoji    = "📥",
                title    = "Keine Downloads",
                subtitle = "Heruntergeladene Inhalte sind auch offline verfügbar.",
                modifier = Modifier.padding(padding)
            )
        } else {
            LazyColumn(
                contentPadding      = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier            = Modifier.padding(padding)
            ) {
                item {
                    Text(
                        "${downloads.size} offline verfügbar",
                        style = MaterialTheme.typography.labelMedium,
                        color = EmeraldAccent
                    )
                }
                items(downloads, key = { it.id }) { content ->
                    ContentCard(
                        content  = content,
                        onClick  = { onContentClick(content.id) },
                        modifier = Modifier
                    )
                }
            }
        }
    }
}
