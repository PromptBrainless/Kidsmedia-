package de.fynn.kidsmedia.feature.contentdetail

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.model.ContentType
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DetailUiState(
    val isLoading: Boolean  = true,
    val content:   Content? = null,
    val error:     String?  = null
)

@HiltViewModel
class ContentDetailViewModel @Inject constructor(
    private val repository:      ContentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val contentId: String = checkNotNull(savedStateHandle["contentId"])

    private val _state = MutableStateFlow(DetailUiState())
    val state: StateFlow<DetailUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeAll()
                .map { list -> list.firstOrNull { it.id == contentId } }
                .collect { content ->
                    _state.update {
                        it.copy(
                            isLoading = false,
                            content   = content,
                            error     = if (content == null) "Inhalt nicht gefunden" else null
                        )
                    }
                }
        }
    }
}
