package de.fynn.kidsmedia.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import de.fynn.kidsmedia.feature.contentdetail.ContentDetailScreen
import de.fynn.kidsmedia.feature.discover.DiscoverScreen
import de.fynn.kidsmedia.feature.downloads.DownloadsScreen
import de.fynn.kidsmedia.feature.favorites.FavoritesScreen
import de.fynn.kidsmedia.feature.home.HomeScreen
import de.fynn.kidsmedia.feature.library.LibraryScreen
import de.fynn.kidsmedia.feature.player.PlayerScreen
import de.fynn.kidsmedia.feature.reader.ReaderScreen
import de.fynn.kidsmedia.feature.settings.SettingsScreen

sealed class Screen(val route: String) {
    object Home        : Screen("home")
    object Discover    : Screen("discover")
    object Library     : Screen("library")
    object Downloads   : Screen("downloads")
    object Favorites   : Screen("favorites")
    object Settings    : Screen("settings")
    object ContentDetail : Screen("content/{contentId}") {
        fun createRoute(id: String) = "content/$id"
    }
    object Player      : Screen("player/{contentId}") {
        fun createRoute(id: String) = "player/$id"
    }
    object Reader      : Screen("reader/{contentId}") {
        fun createRoute(id: String) = "reader/$id"
    }
}

@Composable
fun KidsMediaNavGraph() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onContentClick  = { id -> navController.navigate(Screen.ContentDetail.createRoute(id)) },
                onDiscoverClick = { navController.navigate(Screen.Discover.route) },
                onSettingsClick = { navController.navigate(Screen.Settings.route) }
            )
        }

        composable(Screen.Discover.route) {
            DiscoverScreen(
                onContentClick = { id -> navController.navigate(Screen.ContentDetail.createRoute(id)) },
                onBack         = { navController.popBackStack() }
            )
        }

        composable(Screen.Library.route) {
            LibraryScreen(
                onContentClick = { id -> navController.navigate(Screen.ContentDetail.createRoute(id)) },
                onBack         = { navController.popBackStack() }
            )
        }

        composable(Screen.Downloads.route) {
            DownloadsScreen(
                onContentClick = { id -> navController.navigate(Screen.ContentDetail.createRoute(id)) },
                onBack         = { navController.popBackStack() }
            )
        }

        composable(Screen.Favorites.route) {
            FavoritesScreen(
                onContentClick = { id -> navController.navigate(Screen.ContentDetail.createRoute(id)) },
                onBack         = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route     = Screen.ContentDetail.route,
            arguments = listOf(navArgument("contentId") { type = NavType.StringType })
        ) { back ->
            val id = back.arguments?.getString("contentId") ?: return@composable
            ContentDetailScreen(
                contentId   = id,
                onPlayVideo = { navController.navigate(Screen.Player.createRoute(id)) },
                onReadPdf   = { navController.navigate(Screen.Reader.createRoute(id)) },
                onBack      = { navController.popBackStack() }
            )
        }

        composable(
            route     = Screen.Player.route,
            arguments = listOf(navArgument("contentId") { type = NavType.StringType })
        ) { back ->
            val id = back.arguments?.getString("contentId") ?: return@composable
            PlayerScreen(
                contentId = id,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(
            route     = Screen.Reader.route,
            arguments = listOf(navArgument("contentId") { type = NavType.StringType })
        ) { back ->
            val id = back.arguments?.getString("contentId") ?: return@composable
            ReaderScreen(
                contentId = id,
                onBack    = { navController.popBackStack() }
            )
        }
    }
}
