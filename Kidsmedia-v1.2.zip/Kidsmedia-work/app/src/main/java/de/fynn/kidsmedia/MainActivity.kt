package de.fynn.kidsmedia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import dagger.hilt.android.AndroidEntryPoint
import de.fynn.kidsmedia.core.ui.KidsMediaTheme
import de.fynn.kidsmedia.navigation.KidsMediaNavGraph

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KidsMediaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    KidsMediaNavGraph()
                }
            }
        }
    }
}
