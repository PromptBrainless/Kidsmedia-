import React, { useState, useEffect, useCallback } from "react";
import {
  UserPlus, Trash2, Plus, X, BookOpen,
  CheckCircle2, Star, Award, ChevronRight, Loader2, RefreshCw
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "../lib/firebase.ts";

interface ChildProfile {
  id: number;
  name: string;
  age: number;
  emoji: string;
  xp: number;
  level: number;
  interests: string[];
  badges: string[];
  createdAt: string;
}

interface Assignment {
  assignmentId: number;
  assignedAt: string;
  expiresAt: string | null;
  completed: number;
  completedAt: string | null;
  itemId: number;
  title: string;
  itemType: string;
  category: string;
  description: string | null;
  coverUrl: string | null;
  ageRating: number;
  publishStatus: string;
}

interface LibraryItem {
  id: number;
  title: string;
  itemType: string;
  category: string;
  description: string | null;
  ageRating: number;
  publishStatus: string;
}

interface KinderTabProps {
  libraryItemsList: LibraryItem[];
  addUiLog: (msg: string, type: "info" | "success" | "warn") => void;
}

// ── API-Helper ────────────────────────────────────────────────────────────────
async function apiFetch(path: string, options: RequestInit = {}) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "demo-token";
  const res = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || res.statusText);
  }
  return res.json();
}

const INTEREST_OPTIONS = [
  "Natur & Tiere 🌿", "Weltraum 🚀", "Technik ⚙️", "Musik 🎵",
  "Märchen ✨", "Geografie 🌍", "Geschichte 🏛️", "Sport ⚽",
  "Kunst 🎨", "Wissenschaft 🔬",
];

// ── Hauptkomponente ───────────────────────────────────────────────────────────
export const KinderTab: React.FC<KinderTabProps> = ({ libraryItemsList, addUiLog }) => {
  const [profiles, setProfiles]             = useState<ChildProfile[]>([]);
  const [loading, setLoading]               = useState(true);
  const [selectedChild, setSelectedChild]   = useState<ChildProfile | null>(null);
  const [assignments, setAssignments]       = useState<Assignment[]>([]);
  const [loadingAssign, setLoadingAssign]   = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showAssignPanel, setShowAssignPanel] = useState(false);

  // Formular-State
  const [formName, setFormName]         = useState("");
  const [formAge, setFormAge]           = useState(8);
  const [formEmoji, setFormEmoji]       = useState("🌟");
  const [formInterests, setFormInterests] = useState<string[]>([]);
  const [formSaving, setFormSaving]     = useState(false);

  // Zuweisung
  const [assignSearch, setAssignSearch] = useState("");
  const approvedItems = libraryItemsList.filter(
    (i) => i.publishStatus === "approved" || !i.publishStatus
  );

  // ── Laden ────────────────────────────────────────────────────────────────
  const loadProfiles = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetch("/api/children");
      const parsed = data.map((p: any) => ({
        ...p,
        interests: typeof p.interests === "string" ? JSON.parse(p.interests) : p.interests || [],
        badges:    typeof p.badges    === "string" ? JSON.parse(p.badges)    : p.badges    || [],
      }));
      setProfiles(parsed);
      addUiLog(`${parsed.length} Kindprofile geladen.`, "success");
    } catch (e: any) {
      // Demo-Fallback wenn noch keine API-Verbindung
      setProfiles([]);
      addUiLog(`Kindprofile: ${e.message} (keine API-Verbindung – lokal)`, "warn");
    } finally {
      setLoading(false);
    }
  }, [addUiLog]);

  const loadAssignments = useCallback(async (child: ChildProfile) => {
    setLoadingAssign(true);
    try {
      const data = await apiFetch(`/api/children/${child.id}/content`);
      setAssignments(data);
    } catch (e: any) {
      setAssignments([]);
      addUiLog(`Zuweisungen: ${e.message}`, "warn");
    } finally {
      setLoadingAssign(false);
    }
  }, [addUiLog]);

  useEffect(() => { loadProfiles(); }, [loadProfiles]);

  useEffect(() => {
    if (selectedChild) loadAssignments(selectedChild);
  }, [selectedChild, loadAssignments]);

  // ── Profil erstellen ──────────────────────────────────────────────────────
  const handleCreateProfile = async () => {
    if (!formName.trim() || formAge < 3 || formAge > 17) {
      addUiLog("Name und Alter (3–17) sind Pflichtfelder.", "warn");
      return;
    }
    setFormSaving(true);
    try {
      const created = await apiFetch("/api/children", {
        method: "POST",
        body: JSON.stringify({
          name:      formName.trim(),
          age:       formAge,
          emoji:     formEmoji,
          interests: formInterests,
        }),
      });
      const parsed = {
        ...created,
        interests: typeof created.interests === "string" ? JSON.parse(created.interests) : created.interests || [],
        badges:    typeof created.badges    === "string" ? JSON.parse(created.badges)    : created.badges    || [],
      };
      setProfiles((prev) => [parsed, ...prev]);
      setFormName(""); setFormAge(8); setFormEmoji("🌟"); setFormInterests([]);
      setShowCreateForm(false);
      addUiLog(`Profil "${parsed.name}" (${parsed.age} Jahre) erfolgreich angelegt.`, "success");
    } catch (e: any) {
      addUiLog(`Fehler beim Erstellen: ${e.message}`, "warn");
    } finally {
      setFormSaving(false);
    }
  };

  // ── Profil löschen ────────────────────────────────────────────────────────
  const handleDeleteProfile = async (id: number, name: string) => {
    if (!confirm(`Kindprofil "${name}" wirklich löschen? Alle Zuweisungen werden entfernt.`)) return;
    try {
      await apiFetch(`/api/children/${id}`, { method: "DELETE" });
      setProfiles((prev) => prev.filter((p) => p.id !== id));
      if (selectedChild?.id === id) { setSelectedChild(null); setAssignments([]); }
      addUiLog(`Profil "${name}" gelöscht.`, "info");
    } catch (e: any) {
      addUiLog(`Löschen fehlgeschlagen: ${e.message}`, "warn");
    }
  };

  // ── Inhalt zuweisen ───────────────────────────────────────────────────────
  const handleAssign = async (item: LibraryItem) => {
    if (!selectedChild) return;
    try {
      const created = await apiFetch(`/api/children/${selectedChild.id}/content`, {
        method: "POST",
        body: JSON.stringify({ libraryItemId: item.id }),
      });
      setAssignments((prev) => [{
        assignmentId: created.id,
        assignedAt:   created.assignedAt,
        expiresAt:    null,
        completed:    0,
        completedAt:  null,
        itemId:       item.id,
        title:        item.title,
        itemType:     item.itemType,
        category:     item.category,
        description:  item.description,
        coverUrl:     item.coverUrl ?? null,
        ageRating:    item.ageRating,
        publishStatus: item.publishStatus,
      }, ...prev]);
      addUiLog(`"${item.title}" → ${selectedChild.name} zugewiesen.`, "success");
    } catch (e: any) {
      addUiLog(`Zuweisung fehlgeschlagen: ${e.message}`, "warn");
    }
  };

  // ── Zuweisung entfernen ───────────────────────────────────────────────────
  const handleRemoveAssignment = async (assignmentId: number, title: string) => {
    if (!selectedChild) return;
    try {
      await apiFetch(`/api/children/${selectedChild.id}/content/${assignmentId}`, { method: "DELETE" });
      setAssignments((prev) => prev.filter((a) => a.assignmentId !== assignmentId));
      addUiLog(`Zuweisung "${title}" entfernt.`, "info");
    } catch (e: any) {
      addUiLog(`Entfernen fehlgeschlagen: ${e.message}`, "warn");
    }
  };

  // ── Filterliste für Zuweisung ─────────────────────────────────────────────
  const alreadyAssignedIds = new Set(assignments.map((a) => a.itemId));
  const filteredForAssign = approvedItems.filter((item) => {
    if (alreadyAssignedIds.has(item.id)) return false;
    if (!assignSearch.trim()) return true;
    return (
      item.title.toLowerCase().includes(assignSearch.toLowerCase()) ||
      (item.category || "").toLowerCase().includes(assignSearch.toLowerCase())
    );
  });

  // ── RENDER ────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            👶 Kinder-Profile &amp; Inhalts-Zuweisung
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Lege Profile an und weise jedem Kind individuell Bildungsinhalte zu.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={loadProfiles}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition cursor-pointer"
            title="Aktualisieren"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowCreateForm(true)}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" /> Profil anlegen
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

        {/* ── Profil-Liste ─────────────────────────────────────────────── */}
        <div className="xl:col-span-1 space-y-3">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            Profile ({profiles.length})
          </span>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-indigo-500" />
            </div>
          ) : profiles.length === 0 ? (
            <div className="p-8 border-2 border-dashed border-slate-800 rounded-2xl text-center text-slate-500 text-xs">
              <span className="text-3xl block mb-2">👶</span>
              Noch keine Kindprofile.<br />Lege das erste an!
            </div>
          ) : (
            profiles.map((child) => (
              <button
                key={child.id}
                onClick={() => { setSelectedChild(child); setShowAssignPanel(false); }}
                className={`w-full p-4 rounded-2xl border text-left transition cursor-pointer ${
                  selectedChild?.id === child.id
                    ? "bg-emerald-950/40 border-emerald-700 text-white"
                    : "bg-slate-950 border-slate-850 text-slate-300 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl bg-slate-900 p-2 rounded-xl border border-slate-800">
                      {child.emoji}
                    </span>
                    <div>
                      <span className="font-bold text-sm block">{child.name}</span>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] text-slate-400">{child.age} Jahre</span>
                        <span className="text-[10px] bg-amber-950 text-amber-300 px-1.5 py-0.5 rounded font-mono">
                          Lv.{child.level}
                        </span>
                        <span className="text-[10px] text-indigo-400 font-mono">{child.xp} XP</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <ChevronRight className="w-4 h-4 opacity-40" />
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDeleteProfile(child.id, child.name); }}
                      className="p-1 text-slate-600 hover:text-rose-400 transition rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                {child.interests.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {child.interests.slice(0, 3).map((i) => (
                      <span key={i} className="text-[9px] bg-slate-900 border border-slate-800 px-1.5 py-0.5 rounded text-slate-400">
                        {i}
                      </span>
                    ))}
                  </div>
                )}
              </button>
            ))
          )}
        </div>

        {/* ── Detail / Zuweisungen ─────────────────────────────────────── */}
        <div className="xl:col-span-2 space-y-4">
          {!selectedChild ? (
            <div className="flex items-center justify-center h-64 border-2 border-dashed border-slate-800 rounded-2xl text-slate-500 text-xs text-center">
              <div>
                <span className="text-3xl block mb-2">👈</span>
                Wähle links ein Kindprofil aus.
              </div>
            </div>
          ) : (
            <>
              {/* Kind-Header */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <span className="text-4xl">{selectedChild.emoji}</span>
                  <div>
                    <h3 className="font-bold text-lg text-white">{selectedChild.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-slate-400">{selectedChild.age} Jahre</span>
                      <span className="text-xs bg-amber-950 text-amber-300 px-2 py-0.5 rounded-full font-bold">
                        Level {selectedChild.level}
                      </span>
                      <span className="text-xs text-indigo-400 font-mono">{selectedChild.xp} XP</span>
                    </div>
                    {selectedChild.badges.length > 0 && (
                      <div className="flex gap-1 mt-2 flex-wrap">
                        {selectedChild.badges.map((b) => (
                          <span key={b} className="text-[10px] bg-violet-950 border border-violet-800 text-violet-300 px-1.5 py-0.5 rounded">
                            {b}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => setShowAssignPanel((p) => !p)}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Inhalt zuweisen
                </button>
              </div>

              {/* Zuweisungs-Picker */}
              <AnimatePresence>
                {showAssignPanel && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="bg-slate-950 border border-indigo-800/60 rounded-2xl p-4 space-y-3 overflow-hidden"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-indigo-400">
                        Inhalt auswählen ({approvedItems.length - alreadyAssignedIds.size} verfügbar)
                      </span>
                      <button onClick={() => setShowAssignPanel(false)} className="text-slate-500 hover:text-white cursor-pointer">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <input
                      type="text"
                      placeholder="Suchen…"
                      value={assignSearch}
                      onChange={(e) => setAssignSearch(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                    <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1">
                      {filteredForAssign.length === 0 ? (
                        <p className="text-slate-500 text-xs text-center py-4 italic">
                          Alle Inhalte bereits zugewiesen oder kein Treffer.
                        </p>
                      ) : (
                        filteredForAssign.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between p-2.5 bg-slate-900 border border-slate-850 rounded-xl hover:border-slate-700 transition"
                          >
                            <div className="min-w-0">
                              <span className="text-xs font-semibold text-white block truncate">{item.title}</span>
                              <span className="text-[10px] text-slate-400">{item.category} · Alter {item.ageRating}+</span>
                            </div>
                            <button
                              onClick={() => handleAssign(item)}
                              className="ml-3 shrink-0 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] px-2.5 py-1 rounded-lg transition cursor-pointer"
                            >
                              Zuweisen
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Aktuelle Zuweisungen */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    Zugewiesene Inhalte ({assignments.length})
                  </span>
                  {loadingAssign && <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400" />}
                </div>

                {assignments.length === 0 && !loadingAssign ? (
                  <div className="p-8 border-2 border-dashed border-slate-800 rounded-2xl text-center text-slate-500 text-xs">
                    <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    Noch keine Inhalte zugewiesen.<br />
                    Klicke auf „Inhalt zuweisen", um zu starten.
                  </div>
                ) : (
                  assignments.map((a) => (
                    <div
                      key={a.assignmentId}
                      className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition ${
                        a.completed
                          ? "bg-emerald-950/20 border-emerald-900/50"
                          : "bg-slate-900 border-slate-800"
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="text-xl shrink-0">
                          {a.itemType === "book" ? "📖" : a.itemType === "audiobook" ? "🎙️" : "📝"}
                        </span>
                        <div className="min-w-0">
                          <span className="text-xs font-semibold text-white block truncate">{a.title}</span>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[10px] text-slate-400">{a.category}</span>
                            {a.completed ? (
                              <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-0.5">
                                <CheckCircle2 className="w-3 h-3" /> Abgeschlossen
                              </span>
                            ) : (
                              <span className="text-[10px] text-slate-500">
                                Zugewiesen {new Date(a.assignedAt).toLocaleDateString("de-DE")}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => handleRemoveAssignment(a.assignmentId, a.title)}
                        className="shrink-0 p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition cursor-pointer"
                        title="Zuweisung entfernen"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {/* ── Profil-Erstell-Modal ────────────────────────────────────────── */}
      <AnimatePresence>
        {showCreateForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, y: 16 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 16 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-5"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-white text-base">Neues Kindprofil</h3>
                <button onClick={() => setShowCreateForm(false)} className="text-slate-500 hover:text-white cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4 text-xs">
                {/* Emoji */}
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1.5">Profilbild-Emoji</label>
                  <div className="flex flex-wrap gap-2">
                    {["🌟","🚀","🦁","🐬","🦋","🌈","🐉","🎮","📚","🎨"].map((em) => (
                      <button
                        key={em}
                        onClick={() => setFormEmoji(em)}
                        className={`text-xl p-2 rounded-xl border transition cursor-pointer ${
                          formEmoji === em
                            ? "bg-indigo-950 border-indigo-600"
                            : "bg-slate-950 border-slate-850 hover:border-slate-700"
                        }`}
                      >{em}</button>
                    ))}
                  </div>
                </div>

                {/* Name + Alter */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Vorname *</label>
                    <input
                      type="text"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      placeholder="z.B. Lena"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Alter *</label>
                    <input
                      type="number"
                      min={3} max={17}
                      value={formAge}
                      onChange={(e) => setFormAge(parseInt(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                {/* Interessen */}
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1.5">
                    Interessen ({formInterests.length} ausgewählt)
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {INTEREST_OPTIONS.map((opt) => (
                      <button
                        key={opt}
                        onClick={() => setFormInterests((prev) =>
                          prev.includes(opt) ? prev.filter((i) => i !== opt) : [...prev, opt]
                        )}
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-lg border transition cursor-pointer ${
                          formInterests.includes(opt)
                            ? "bg-indigo-950 border-indigo-600 text-indigo-300"
                            : "bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-700"
                        }`}
                      >{opt}</button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => setShowCreateForm(false)}
                    className="flex-1 bg-slate-950 border border-slate-800 text-slate-300 font-bold py-2.5 rounded-xl hover:bg-slate-900 transition cursor-pointer"
                  >
                    Abbrechen
                  </button>
                  <button
                    onClick={handleCreateProfile}
                    disabled={formSaving || !formName.trim()}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-bold py-2.5 rounded-xl transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    {formSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                    Profil speichern
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
