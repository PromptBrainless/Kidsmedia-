package de.fynn.kidsmedia.feature.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import de.fynn.kidsmedia.core.model.ContentType
import de.fynn.kidsmedia.core.ui.*

@Composable
fun PlayerScreen(
    contentId: String,
    onBack:    () -> Unit,
    viewModel: PlayerViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            KidsMediaTopBar(
                title  = state.content?.title ?: "Wiedergabe",
                onBack = onBack
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->

        when {
            state.isLoading -> LoadingScreen(Modifier.padding(padding))
            state.content == null -> EmptyState("⚠️", "Fehler", "Inhalt nicht gefunden")
            else -> PlayerBody(
                state     = state,
                onToggle  = viewModel::togglePlay,
                onSeek    = viewModel::seekTo,
                modifier  = Modifier.padding(padding)
            )
        }
    }
}

@Composable
private fun PlayerBody(
    state:    PlayerUiState,
    onToggle: () -> Unit,
    onSeek:   (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val content = state.content!!

    Column(
        modifier            = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        // ── Artwork / Video Area ──────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Brush.verticalGradient(listOf(Surface950, Surface800))),
            contentAlignment = Alignment.Center
        ) {
            when (content.type) {
                ContentType.VIDEO -> {
                    // In der echten App: AndroidView mit ExoPlayer hier einbinden
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎬", style = MaterialTheme.typography.displayLarge)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Video-Player",
                            style = MaterialTheme.typography.bodySmall,
                            color = OnSurface400
                        )
                    }
                }
                ContentType.AUDIO -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Animiertes Artwork für Audio
                        Box(
                            modifier = Modifier
                                .size(180.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(listOf(IndigoBase, IndigoDark))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🎙️", style = MaterialTheme.typography.displayLarge)
                        }
                    }
                }
                else -> Text(contentTypeEmoji(content.type),
                             style = MaterialTheme.typography.displayLarge)
            }
        }

        // ── Controls Area ──────────────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Title
            Text(content.title, style = MaterialTheme.typography.titleLarge)
            Text(content.category,
                 style = MaterialTheme.typography.bodySmall,
                 color = MaterialTheme.colorScheme.onSurfaceVariant)

            // Progress Slider
            Slider(
                value         = state.progress,
                onValueChange = onSeek,
                modifier      = Modifier.fillMaxWidth(),
                colors        = SliderDefaults.colors(
                    thumbColor       = TealAccent,
                    activeTrackColor = TealAccent
                )
            )

            // Time labels
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val total = content.durationSeconds ?: 0
                Text(formatDuration((state.progress * total).toInt()),
                     style = MaterialTheme.typography.labelSmall,
                     color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(formatDuration(total),
                     style = MaterialTheme.typography.labelSmall,
                     color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // Play Controls
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onSeek(maxOf(0f, state.progress - 0.05f)) }) {
                    Icon(Icons.Default.SkipPrevious, "Zurückspulen",
                         modifier = Modifier.size(36.dp))
                }
                Spacer(Modifier.width(16.dp))
                FilledIconButton(
                    onClick  = onToggle,
                    modifier = Modifier.size(64.dp),
                    shape    = CircleShape,
                    colors   = IconButtonDefaults.filledIconButtonColors(
                        containerColor = IndigoBase,
                        contentColor   = Color.White
                    )
                ) {
                    Icon(
                        if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (state.isPlaying) "Pause" else "Abspielen",
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(Modifier.width(16.dp))
                IconButton(onClick = { onSeek(minOf(1f, state.progress + 0.05f)) }) {
                    Icon(Icons.Default.SkipNext, "Vorspulen",
                         modifier = Modifier.size(36.dp))
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}
