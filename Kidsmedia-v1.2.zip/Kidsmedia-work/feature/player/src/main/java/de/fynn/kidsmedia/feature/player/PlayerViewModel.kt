package de.fynn.kidsmedia.feature.player

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.model.Content
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PlayerUiState(
    val isLoading: Boolean  = true,
    val content:   Content? = null,
    val isPlaying: Boolean  = false,
    val progress:  Float    = 0f,
    val error:     String?  = null
)

@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val repository: ContentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val contentId: String = checkNotNull(savedStateHandle["contentId"])
    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeAll()
                .map { list -> list.firstOrNull { it.id == contentId } }
                .collect { content ->
                    _state.update {
                        it.copy(
                            isLoading = false,
                            content   = content,
                            progress  = content?.progress ?: 0f
                        )
                    }
                }
        }
    }

    fun togglePlay() = _state.update { it.copy(isPlaying = !it.isPlaying) }

    fun seekTo(pos: Float) = _state.update { it.copy(progress = pos.coerceIn(0f, 1f)) }
}
