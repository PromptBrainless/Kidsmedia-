package de.fynn.kidsmedia.feature.favorites

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.ui.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class FavoritesViewModel @Inject constructor(
    repository: ContentRepository
) : ViewModel() {
    val favorites: StateFlow<List<Content>> = repository.observeAll()
        .map { list -> list.filter { it.isFavorite } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

@Composable
fun FavoritesScreen(
    onContentClick: (String) -> Unit,
    onBack:         () -> Unit,
    viewModel:      FavoritesViewModel = hiltViewModel()
) {
    val favorites by viewModel.favorites.collectAsState()

    Scaffold(
        topBar = { KidsMediaTopBar(title = "Favoriten ★", onBack = onBack) }
    ) { padding ->
        if (favorites.isEmpty()) {
            EmptyState(
                emoji    = "★",
                title    = "Noch keine Favoriten",
                subtitle = "Tippe auf ★ bei einem Inhalt, um ihn hier zu speichern.",
                modifier = Modifier.padding(padding)
            )
        } else {
            LazyColumn(
                contentPadding      = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier            = Modifier.padding(padding)
            ) {
                items(favorites, key = { it.id }) { content ->
                    ContentCard(content = content, onClick = { onContentClick(content.id) })
                }
            }
        }
    }
}
