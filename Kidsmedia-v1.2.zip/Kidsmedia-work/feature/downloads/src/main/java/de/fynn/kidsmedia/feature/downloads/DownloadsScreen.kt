package de.fynn.kidsmedia.feature.downloads

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.data.DownloadStatus
import de.fynn.kidsmedia.core.data.KidsMediaDownloadManager
import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.ui.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DownloadsUiState(
    val downloads:      List<Content>          = emptyList(),
    val activeDownload: String?                = null,  // contentId
    val downloadPct:    Int                    = 0,
    val storageMb:      Long                   = 0L,
    val error:          String?                = null
)

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val repository:       ContentRepository,
    private val downloadManager:  KidsMediaDownloadManager
) : ViewModel() {

    private val _state = MutableStateFlow(DownloadsUiState())
    val state: StateFlow<DownloadsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeDownloads().collect { list ->
                _state.update {
                    it.copy(
                        downloads  = list,
                        storageMb  = downloadManager.totalDownloadSizeBytes() / 1024 / 1024
                    )
                }
            }
        }
    }

    fun startDownload(content: Content) {
        val url      = content.remoteUrl ?: return
        val fileName = "${content.id}.${url.substringAfterLast('.', "mp4")}"

        viewModelScope.launch {
            downloadManager.download(content.id, url, fileName).collect { status ->
                when (status) {
                    is DownloadStatus.Downloading -> _state.update {
                        it.copy(activeDownload = content.id, downloadPct = status.progress)
                    }
                    is DownloadStatus.Done        -> _state.update {
                        it.copy(activeDownload = null, downloadPct = 0)
                    }
                    is DownloadStatus.Failed      -> _state.update {
                        it.copy(activeDownload = null, error = status.reason)
                    }
                    else -> {}
                }
            }
        }
    }

    fun deleteDownload(content: Content) {
        viewModelScope.launch {
            content.localPath?.let { path ->
                downloadManager.deleteDownload(content.id, path)
            }
        }
    }

    fun clearError() = _state.update { it.copy(error = null) }
}

// ── Screen ────────────────────────────────────────────────────────────────────
@Composable
fun DownloadsScreen(
    onContentClick: (String) -> Unit,
    onBack:         () -> Unit,
    viewModel:      DownloadsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = { KidsMediaTopBar(title = "Downloads", onBack = onBack) }
    ) { padding ->

        Column(modifier = Modifier.padding(padding)) {

            // ── Speicherplatz-Banner ──────────────────────────────────
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier              = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Offline-Speicher", style = MaterialTheme.typography.labelLarge)
                        Text(
                            "${state.storageMb} MB belegt",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        Icons.Default.Download,
                        contentDescription = null,
                        tint = EmeraldAccent
                    )
                }
            }

            // ── Aktiver Download Progress ─────────────────────────────
            if (state.activeDownload != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier              = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Download läuft…",
                             style = MaterialTheme.typography.labelMedium,
                             color = TealAccent)
                        Text("${state.downloadPct}%",
                             style = MaterialTheme.typography.labelMedium,
                             color = TealAccent)
                    }
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress       = { state.downloadPct / 100f },
                        modifier       = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color          = TealAccent,
                        trackColor     = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }

            // ── Liste ─────────────────────────────────────────────────
            if (state.downloads.isEmpty()) {
                EmptyState(
                    emoji    = "📥",
                    title    = "Keine Downloads",
                    subtitle = "Öffne einen Inhalt und lade ihn herunter – dann ist er offline verfügbar."
                )
            } else {
                LazyColumn(
                    contentPadding      = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            "${state.downloads.size} Inhalte offline verfügbar",
                            style = MaterialTheme.typography.labelMedium,
                            color = EmeraldAccent
                        )
                    }
                    items(state.downloads, key = { it.id }) { content ->
                        Row(
                            modifier          = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ContentCard(
                                content  = content,
                                onClick  = { onContentClick(content.id) },
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            IconButton(
                                onClick = { viewModel.deleteDownload(content) }
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Löschen",
                                    tint = RoseAlert
                                )
                            }
                        }
                    }
                }
            }
        }

        // Error Snackbar
        state.error?.let { err ->
            LaunchedEffect(err) {
                viewModel.clearError()
            }
        }
    }
}
