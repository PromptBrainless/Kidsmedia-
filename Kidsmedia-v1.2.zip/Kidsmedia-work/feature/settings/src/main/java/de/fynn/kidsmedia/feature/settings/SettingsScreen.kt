package de.fynn.kidsmedia.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.ui.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val darkMode:       Boolean = true,
    val autoSync:       Boolean = true,
    val downloadOnWifi: Boolean = true,
    val isSyncing:      Boolean = false,
    val syncMessage:    String? = null,
    val appVersion:     String  = "1.0.0"
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repository: ContentRepository
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsUiState())
    val state: StateFlow<SettingsUiState> = _state.asStateFlow()

    fun toggleDarkMode()       = _state.update { it.copy(darkMode = !it.darkMode) }
    fun toggleAutoSync()       = _state.update { it.copy(autoSync = !it.autoSync) }
    fun toggleDownloadOnWifi() = _state.update { it.copy(downloadOnWifi = !it.downloadOnWifi) }

    fun syncNow() {
        viewModelScope.launch {
            _state.update { it.copy(isSyncing = true, syncMessage = null) }
            runCatching { repository.syncManifest() }
                .onSuccess { _state.update { it.copy(isSyncing = false, syncMessage = "Synchronisierung erfolgreich!") } }
                .onFailure { e -> _state.update { it.copy(isSyncing = false, syncMessage = "Fehler: ${e.message}") } }
        }
    }
}

@Composable
fun SettingsScreen(
    onBack:    () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = { KidsMediaTopBar(title = "Einstellungen", onBack = onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // ── Darstellung ───────────────────────────────────────────
            SectionHeader(title = "DARSTELLUNG")

            SettingRow(
                icon    = Icons.Default.DarkMode,
                title   = "Dunkles Design",
                sub     = "Augenfreundlicher Dunkelmodus",
                checked = state.darkMode,
                onToggle = viewModel::toggleDarkMode
            )

            // ── Synchronisierung ───────────────────────────────────────
            SectionHeader(title = "SYNCHRONISIERUNG")

            SettingRow(
                icon    = Icons.Default.Sync,
                title   = "Automatische Synchronisierung",
                sub     = "Neue Inhalte beim Start abrufen",
                checked = state.autoSync,
                onToggle = viewModel::toggleAutoSync
            )

            SettingRow(
                icon    = Icons.Default.Storage,
                title   = "Nur über WLAN downloaden",
                sub     = "Spart mobile Daten",
                checked = state.downloadOnWifi,
                onToggle = viewModel::toggleDownloadOnWifi
            )

            // Manual sync button
            Button(
                onClick  = viewModel::syncNow,
                enabled  = !state.isSyncing,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state.isSyncing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text("Jetzt synchronisieren")
            }

            state.syncMessage?.let { msg ->
                Text(
                    text  = msg,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (msg.startsWith("Fehler")) RoseAlert else EmeraldAccent
                )
            }

            // ── Info ──────────────────────────────────────────────────
            SectionHeader(title = "INFO")

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = MaterialTheme.shapes.large
            ) {
                Row(
                    modifier            = Modifier.padding(16.dp),
                    verticalAlignment   = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.Info, "Info",
                         tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Column {
                        Text("KidsMedia", style = MaterialTheme.typography.titleMedium)
                        Text("Version ${state.appVersion}",
                             style = MaterialTheme.typography.bodySmall,
                             color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Geschlossene Bildungsplattform · DSGVO-konform",
                             style = MaterialTheme.typography.labelSmall,
                             color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingRow(
    icon:     androidx.compose.ui.graphics.vector.ImageVector,
    title:    String,
    sub:      String,
    checked:  Boolean,
    onToggle: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = MaterialTheme.shapes.large
    ) {
        Row(
            modifier            = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment   = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, title, tint = MaterialTheme.colorScheme.primary)
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(sub, style = MaterialTheme.typography.bodySmall,
                     color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = { onToggle() })
        }
    }
}
