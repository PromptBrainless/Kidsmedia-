package de.fynn.kidsmedia.feature.library

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.ui.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── ViewModel ─────────────────────────────────────────────────────────────────
@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val repository: ContentRepository
) : ViewModel() {

    val items: StateFlow<List<Content>> = repository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

// ── Screen ────────────────────────────────────────────────────────────────────
@Composable
fun LibraryScreen(
    onContentClick: (String) -> Unit,
    onBack:         () -> Unit,
    viewModel:      LibraryViewModel = hiltViewModel()
) {
    val items by viewModel.items.collectAsState()

    Scaffold(
        topBar = { KidsMediaTopBar(title = "Mediathek", onBack = onBack) }
    ) { padding ->
        if (items.isEmpty()) {
            EmptyState(
                emoji    = "📚",
                title    = "Noch keine Inhalte",
                subtitle = "Synced Inhalte erscheinen hier.",
                modifier = Modifier.padding(padding)
            )
        } else {
            LazyColumn(
                contentPadding      = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier            = Modifier.padding(padding)
            ) {
                items(items, key = { it.id }) { content ->
                    ContentCard(content = content, onClick = { onContentClick(content.id) })
                }
            }
        }
    }
}
