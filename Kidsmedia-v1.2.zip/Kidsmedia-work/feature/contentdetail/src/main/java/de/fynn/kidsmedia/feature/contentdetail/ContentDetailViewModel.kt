package de.fynn.kidsmedia.feature.contentdetail

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.data.DownloadStatus
import de.fynn.kidsmedia.core.data.KidsMediaDownloadManager
import de.fynn.kidsmedia.core.model.Content
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DetailUiState(
    val isLoading:   Boolean  = true,
    val content:     Content? = null,
    val downloadPct: Int?     = null,   // null = kein aktiver Download
    val error:       String?  = null
)

@HiltViewModel
class ContentDetailViewModel @Inject constructor(
    private val repository:      ContentRepository,
    private val downloadManager: KidsMediaDownloadManager,
    savedStateHandle:            SavedStateHandle
) : ViewModel() {

    private val contentId: String = checkNotNull(savedStateHandle["contentId"])

    private val _state = MutableStateFlow(DetailUiState())
    val state: StateFlow<DetailUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeAll()
                .map { list -> list.firstOrNull { it.id == contentId } }
                .collect { content ->
                    _state.update {
                        it.copy(
                            isLoading = false,
                            content   = content,
                            error     = if (content == null) "Inhalt nicht gefunden" else null
                        )
                    }
                }
        }
    }

    fun toggleFavorite() {
        viewModelScope.launch {
            repository.toggleFavorite(contentId)
        }
    }

    fun downloadContent() {
        val content = _state.value.content ?: return
        val url     = content.remoteUrl ?: return
        val ext     = url.substringAfterLast('.', "mp4")

        viewModelScope.launch {
            downloadManager.download(contentId, url, "$contentId.$ext").collect { status ->
                when (status) {
                    is DownloadStatus.Downloading -> _state.update { it.copy(downloadPct = status.progress) }
                    is DownloadStatus.Done        -> _state.update { it.copy(downloadPct = null) }
                    is DownloadStatus.Failed      -> _state.update { it.copy(downloadPct = null, error = status.reason) }
                    else -> {}
                }
            }
        }
    }

    fun deleteDownload() {
        viewModelScope.launch {
            val path = _state.value.content?.localPath ?: return@launch
            downloadManager.deleteDownload(contentId, path)
        }
    }

    fun clearError() = _state.update { it.copy(error = null) }
}
