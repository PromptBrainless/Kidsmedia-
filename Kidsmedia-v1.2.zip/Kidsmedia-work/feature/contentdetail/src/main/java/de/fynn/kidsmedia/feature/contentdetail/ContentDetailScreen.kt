package de.fynn.kidsmedia.feature.contentdetail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.model.ContentType
import de.fynn.kidsmedia.core.ui.*

@Composable
fun ContentDetailScreen(
    contentId:   String,
    onPlayVideo: () -> Unit,
    onReadPdf:   () -> Unit,
    onBack:      () -> Unit,
    viewModel:   ContentDetailViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            KidsMediaTopBar(
                title  = state.content?.title ?: "Details",
                onBack = onBack,
                actions = {
                    // Favorite-Button
                    if (state.content != null) {
                        IconButton(onClick = viewModel::toggleFavorite) {
                            Icon(
                                if (state.content!!.isFavorite) Icons.Default.Favorite
                                else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorit",
                                tint = if (state.content!!.isFavorite) AmberAccent
                                       else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        // Download / Delete
                        if (state.content!!.isDownloaded) {
                            IconButton(onClick = viewModel::deleteDownload) {
                                Icon(Icons.Default.Delete, "Download löschen", tint = RoseAlert)
                            }
                        } else if (state.content!!.remoteUrl != null) {
                            IconButton(
                                onClick  = viewModel::downloadContent,
                                enabled  = state.downloadPct == null
                            ) {
                                Icon(Icons.Default.Download, "Herunterladen", tint = TealAccent)
                            }
                        }
                    }
                }
            )
        }
    ) { padding ->

        when {
            state.isLoading   -> LoadingScreen(Modifier.padding(padding))
            state.error != null && state.content == null ->
                EmptyState("⚠️", "Fehler", state.error!!)
            else -> DetailBody(
                content     = state.content!!,
                downloadPct = state.downloadPct,
                onPlayVideo = onPlayVideo,
                onReadPdf   = onReadPdf,
                modifier    = Modifier.padding(padding)
            )
        }
    }
}

@Composable
private fun DetailBody(
    content:     Content,
    downloadPct: Int?,
    onPlayVideo: () -> Unit,
    onReadPdf:   () -> Unit,
    modifier:    Modifier = Modifier
) {
    Column(modifier = modifier.verticalScroll(rememberScrollState())) {

        // ── Hero ──────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Brush.verticalGradient(listOf(IndigoBase, IndigoDark))),
            contentAlignment = Alignment.Center
        ) {
            Text(contentTypeEmoji(content.type), style = MaterialTheme.typography.displayLarge)
        }

        // ── Download-Progressbar ───────────────────────────────────────
        if (downloadPct != null) {
            Column(modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier              = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Download läuft…",
                         style = MaterialTheme.typography.labelMedium,
                         color = TealAccent)
                    Text("$downloadPct%",
                         style = MaterialTheme.typography.labelMedium,
                         color = TealAccent)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress   = { downloadPct / 100f },
                    modifier   = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color      = TealAccent,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Column(modifier = Modifier.padding(horizontal = 20.dp)) {

            // Badges
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Badge(containerColor = contentTypeColor(content.type)) { Text(content.type.name) }
                Badge(containerColor = MaterialTheme.colorScheme.surfaceVariant) { Text(content.ageGroup) }
                if (content.isDownloaded) Badge(containerColor = EmeraldAccent) { Text("Offline ✓") }
                if (content.isFavorite)   Badge(containerColor = AmberAccent)   { Text("★ Favorit") }
            }

            Spacer(Modifier.height(12.dp))
            Text(content.title, style = MaterialTheme.typography.headlineLarge)
            Text(content.category,
                 style = MaterialTheme.typography.bodyMedium,
                 color = MaterialTheme.colorScheme.onSurfaceVariant)
            content.durationSeconds?.let { dur ->
                Text(formatDuration(dur),
                     style = MaterialTheme.typography.labelMedium,
                     color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // Progress
            if (content.progress > 0f) {
                Spacer(Modifier.height(12.dp))
                Text("Zuletzt gestoppt bei ${(content.progress * 100).toInt()}%",
                     style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress   = { content.progress },
                    modifier   = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp)),
                    color      = TealAccent,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            Spacer(Modifier.height(20.dp))

            // ── CTA Button ────────────────────────────────────────────
            val ctaLabel = when (content.type) {
                ContentType.VIDEO -> "▶  Video abspielen"
                ContentType.AUDIO -> "🎙  Audio abspielen"
                ContentType.PDF   -> "📖  Lesen"
                ContentType.QUIZ  -> "🧠  Quiz starten"
                else              -> "📄  Öffnen"
            }
            val ctaAction = when (content.type) {
                ContentType.PDF -> onReadPdf
                else            -> onPlayVideo
            }
            Button(
                onClick  = ctaAction,
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(14.dp)
            ) { Text(ctaLabel) }

            // ── Beschreibung ───────────────────────────────────────────
            content.description?.let { desc ->
                Spacer(Modifier.height(20.dp))
                Text("Über diesen Inhalt", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text(desc, style = MaterialTheme.typography.bodyMedium,
                     color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // ── Tags ───────────────────────────────────────────────────
            if (content.tags.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Text("Tags", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    content.tags.take(6).forEach { tag ->
                        SuggestionChip(onClick = {}, label = { Text(tag) })
                    }
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}
