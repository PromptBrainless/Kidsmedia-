package de.fynn.kidsmedia.feature.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.TextDecrease
import androidx.compose.material.icons.filled.TextIncrease
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import de.fynn.kidsmedia.core.ui.*

@Composable
fun ReaderScreen(
    contentId: String,
    onBack:    () -> Unit,
    viewModel: ReaderViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    val bgColor   = if (state.darkMode) Surface950 else Color(0xFFFBF9F4)
    val textColor = if (state.darkMode) OnSurface100 else Color(0xFF2C2013)

    Scaffold(
        topBar = {
            KidsMediaTopBar(
                title  = state.content?.title ?: "Lesen",
                onBack = onBack,
                actions = {
                    IconButton(onClick = viewModel::decreaseFontSize) {
                        Icon(Icons.Default.TextDecrease, "Kleiner")
                    }
                    IconButton(onClick = viewModel::increaseFontSize) {
                        Icon(Icons.Default.TextIncrease, "Größer")
                    }
                    IconButton(onClick = viewModel::toggleTheme) {
                        Icon(
                            if (state.darkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            "Design wechseln"
                        )
                    }
                }
            )
        },
        containerColor = bgColor
    ) { padding ->

        when {
            state.isLoading   -> LoadingScreen(Modifier.padding(padding))
            state.content == null -> EmptyState("⚠️", "Fehler", "Inhalt nicht gefunden")
            else -> {
                val content = state.content!!
                Column(
                    modifier = Modifier
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp, vertical = 20.dp)
                ) {
                    // Title
                    Text(
                        text  = content.title,
                        style = MaterialTheme.typography.headlineLarge,
                        color = textColor,
                        fontSize = (state.fontSize + 6).sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text  = content.category,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (state.darkMode) OnSurface400 else Color(0xFF6B5744)
                    )
                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 16.dp),
                        color    = if (state.darkMode) Surface800 else Color(0xFFEBD4B8)
                    )

                    // Body
                    val bodyText = content.description
                        ?: "Kein Inhalt verfügbar. Bitte stelle sicher, dass der Inhalt vollständig heruntergeladen wurde."

                    Text(
                        text     = bodyText,
                        fontSize = state.fontSize.sp,
                        lineHeight = (state.fontSize * 1.6f).sp,
                        color    = textColor
                    )

                    Spacer(Modifier.height(40.dp))

                    // Source chip
                    SuggestionChip(
                        onClick = {},
                        label   = { Text("Quelle: ${content.category}") },
                        shape   = RoundedCornerShape(8.dp)
                    )
                }
            }
        }
    }
}
