package de.fynn.kidsmedia.feature.reader

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.model.Content
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ReaderUiState(
    val isLoading: Boolean  = true,
    val content:   Content? = null,
    val fontSize:  Float    = 16f,
    val darkMode:  Boolean  = true
)

@HiltViewModel
class ReaderViewModel @Inject constructor(
    private val repository: ContentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val contentId: String = checkNotNull(savedStateHandle["contentId"])
    private val _state = MutableStateFlow(ReaderUiState())
    val state: StateFlow<ReaderUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeAll()
                .map { it.firstOrNull { c -> c.id == contentId } }
                .collect { content ->
                    _state.update { it.copy(isLoading = false, content = content) }
                }
        }
    }

    fun increaseFontSize() = _state.update { it.copy(fontSize = (it.fontSize + 2f).coerceAtMost(28f)) }
    fun decreaseFontSize() = _state.update { it.copy(fontSize = (it.fontSize - 2f).coerceAtLeast(12f)) }
    fun toggleTheme()      = _state.update { it.copy(darkMode = !it.darkMode) }
}
