package de.fynn.kidsmedia.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.data.GetHomeFeedUseCase
import de.fynn.kidsmedia.core.data.HomeFeed
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val isLoading: Boolean   = true,
    val feed:      HomeFeed? = null,
    val error:     String?   = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository:       ContentRepository,
    private val getHomeFeedUseCase: GetHomeFeedUseCase
) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            getHomeFeedUseCase.execute().collect { feed ->
                _state.update { it.copy(isLoading = false, feed = feed) }
            }
        }
        syncManifest()
    }

    private fun syncManifest() {
        viewModelScope.launch {
            runCatching { repository.syncManifest() }
                .onFailure { e -> _state.update { it.copy(error = e.message) } }
        }
    }

    fun clearError() = _state.update { it.copy(error = null) }
}
