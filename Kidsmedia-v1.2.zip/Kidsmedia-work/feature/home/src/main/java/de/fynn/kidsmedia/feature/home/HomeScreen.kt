package de.fynn.kidsmedia.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.ui.*

@Composable
fun HomeScreen(
    onContentClick:  (String) -> Unit,
    onDiscoverClick: () -> Unit,
    onSettingsClick: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            KidsMediaTopBar(
                title = "KidsMedia",
                actions = {
                    IconButton(onClick = onDiscoverClick) {
                        Icon(Icons.Default.Search, "Suchen")
                    }
                    IconButton(onClick = onSettingsClick) {
                        Icon(Icons.Default.Settings, "Einstellungen")
                    }
                }
            )
        }
    ) { padding ->

        if (state.isLoading) {
            LoadingScreen(Modifier.padding(padding))
            return@Scaffold
        }

        val feed = state.feed

        LazyColumn(
            modifier            = Modifier.padding(padding),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            contentPadding      = PaddingValues(bottom = 88.dp) // Platz für Mobile Nav
        ) {

            // ── Hero ──────────────────────────────────────────────────
            feed?.featured?.firstOrNull()?.let { hero ->
                item {
                    HeroBanner(content = hero, onClick = { onContentClick(hero.id) })
                }
            }

            // ── Weitermachen ─────────────────────────────────────────
            if (!feed?.continueWatching.isNullOrEmpty()) {
                item { SectionHeader(title = "Weitermachen 🔁") }
                item {
                    LazyRow(
                        contentPadding        = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(feed!!.continueWatching) { c ->
                            ContentChip(c, onClick = { onContentClick(c.id) })
                        }
                    }
                }
            }

            // ── Neu hinzugefügt ────────────────────────────────────────
            if (!feed?.newItems.isNullOrEmpty()) {
                item { SectionHeader(title = "Neu ✨") }
                item {
                    LazyRow(
                        contentPadding        = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(feed!!.newItems.take(8)) { c ->
                            ContentChip(c, onClick = { onContentClick(c.id) })
                        }
                    }
                }
            }

            // ── Kategorien-Reihen ──────────────────────────────────────
            feed?.byCategory?.forEach { (category, items) ->
                if (items.isNotEmpty()) {
                    item {
                        SectionHeader(title = category)
                    }
                    item {
                        LazyRow(
                            contentPadding        = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(items) { c ->
                                ContentChip(c, onClick = { onContentClick(c.id) })
                            }
                        }
                    }
                }
            }

            // ── Empfohlen (vertikal) ──────────────────────────────────
            if (!feed?.recommended.isNullOrEmpty()) {
                item {
                    SectionHeader(title = "Empfohlen für dich 🎯")
                }
                items(feed!!.recommended.take(6), key = { it.id }) { c ->
                    ContentCard(
                        content  = c,
                        onClick  = { onContentClick(c.id) },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            // Empty State
            if (feed == null || (feed.newItems.isEmpty() && feed.featured.isEmpty())) {
                item {
                    EmptyState(
                        emoji    = "📚",
                        title    = "Noch keine Inhalte",
                        subtitle = "Synchronisierung läuft oder noch kein Inhalt verfügbar."
                    )
                }
            }
        }

        // Fehler-Snackbar
        state.error?.let {
            LaunchedEffect(it) { viewModel.clearError() }
        }
    }
}

// ── Hero Banner ───────────────────────────────────────────────────────────────
@Composable
private fun HeroBanner(content: Content, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(230.dp)
            .clickable(onClick = onClick)
            .background(Brush.verticalGradient(listOf(IndigoBase, IndigoDark)))
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(20.dp)
        ) {
            Badge(containerColor = TealAccent) {
                Text(contentTypeEmoji(content.type) + "  " + content.type.name)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text     = content.title,
                style    = MaterialTheme.typography.headlineLarge,
                color    = MaterialTheme.colorScheme.onPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text  = content.category,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f)
            )
        }
    }
}

// ── Horizontal Content Chip ───────────────────────────────────────────────────
@Composable
private fun ContentChip(content: Content, onClick: () -> Unit) {
    Column(
        modifier            = Modifier
            .width(130.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(90.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(contentTypeColor(content.type).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Text(contentTypeEmoji(content.type),
                 style = MaterialTheme.typography.headlineLarge)
            if (content.isDownloaded) {
                Badge(
                    modifier       = Modifier.align(Alignment.TopEnd).padding(6.dp),
                    containerColor = EmeraldAccent
                ) { Text("✓") }
            }
        }
        Text(
            text     = content.title,
            style    = MaterialTheme.typography.labelMedium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (content.progress > 0f) {
            LinearProgressIndicator(
                progress   = { content.progress },
                modifier   = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)),
                color      = TealAccent,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}
