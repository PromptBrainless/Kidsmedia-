package de.fynn.kidsmedia.feature.discover

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import de.fynn.kidsmedia.core.model.ContentType
import de.fynn.kidsmedia.core.ui.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscoverScreen(
    onContentClick: (String) -> Unit,
    onBack: () -> Unit,
    viewModel: DiscoverViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = { KidsMediaTopBar(title = "Entdecken", onBack = onBack) }
    ) { padding ->

        Column(modifier = Modifier.padding(padding)) {

            // ── Suchfeld ──────────────────────────────────────────────
            OutlinedTextField(
                value         = state.query,
                onValueChange = viewModel::onQueryChange,
                modifier      = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder   = { Text("Suchen…") },
                singleLine    = true,
                shape         = MaterialTheme.shapes.large
            )

            // ── Typ-Filter-Chips ───────────────────────────────────────
            LazyRow(
                contentPadding        = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = state.activeType == null,
                        onClick  = { viewModel.onTypeFilter(null) },
                        label    = { Text("Alle") }
                    )
                }
                items(ContentType.entries) { type ->
                    FilterChip(
                        selected = state.activeType == type,
                        onClick  = { viewModel.onTypeFilter(if (state.activeType == type) null else type) },
                        label    = { Text(contentTypeEmoji(type) + " " + type.name) }
                    )
                }
            }

            Spacer(Modifier.height(4.dp))

            // ── Kategorie-Chips ────────────────────────────────────────
            if (state.categories.isNotEmpty()) {
                LazyRow(
                    contentPadding        = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.categories) { cat ->
                        FilterChip(
                            selected = state.activeCategory == cat,
                            onClick  = { viewModel.onCategoryFilter(if (state.activeCategory == cat) null else cat) },
                            label    = { Text(cat) }
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
            }

            // ── Ergebnisliste ─────────────────────────────────────────
            if (state.isLoading) {
                LoadingScreen()
            } else if (state.filtered.isEmpty()) {
                EmptyState(
                    emoji    = "🔍",
                    title    = "Keine Treffer",
                    subtitle = "Versuch andere Suchbegriffe oder Filter."
                )
            } else {
                LazyColumn(
                    contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            "${state.filtered.size} Ergebnisse",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    items(state.filtered, key = { it.id }) { content ->
                        ContentCard(
                            content = content,
                            onClick = { onContentClick(content.id) }
                        )
                    }
                }
            }
        }
    }
}
