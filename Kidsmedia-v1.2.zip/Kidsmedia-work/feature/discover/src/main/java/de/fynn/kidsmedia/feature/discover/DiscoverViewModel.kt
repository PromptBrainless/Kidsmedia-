package de.fynn.kidsmedia.feature.discover

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import de.fynn.kidsmedia.core.data.ContentRepository
import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.model.ContentType
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DiscoverUiState(
    val isLoading:   Boolean       = true,
    val allContent:  List<Content> = emptyList(),
    val query:       String        = "",
    val activeType:  ContentType?  = null,
    val activeCategory: String?    = null
) {
    val filtered: List<Content> get() = allContent.filter { c ->
        val matchesQuery    = query.isBlank() || c.title.contains(query, ignoreCase = true) ||
                              c.description?.contains(query, ignoreCase = true) == true
        val matchesType     = activeType == null || c.type == activeType
        val matchesCategory = activeCategory == null || c.category == activeCategory
        matchesQuery && matchesType && matchesCategory
    }
    val categories: List<String> get() = allContent.map { it.category }.distinct().sorted()
}

@HiltViewModel
class DiscoverViewModel @Inject constructor(
    private val repository: ContentRepository
) : ViewModel() {

    private val _state = MutableStateFlow(DiscoverUiState())
    val state: StateFlow<DiscoverUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeAll().collect { list ->
                _state.update { it.copy(isLoading = false, allContent = list) }
            }
        }
    }

    fun onQueryChange(q: String)          = _state.update { it.copy(query = q) }
    fun onTypeFilter(t: ContentType?)     = _state.update { it.copy(activeType = t) }
    fun onCategoryFilter(c: String?)      = _state.update { it.copy(activeCategory = c) }
}
