package de.fynn.kidsmedia.core.data

import de.fynn.kidsmedia.core.database.ContentDao
import de.fynn.kidsmedia.core.database.ContentEntity
import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.model.ContentType
import de.fynn.kidsmedia.core.network.ContentApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ContentRepository @Inject constructor(
    private val contentDao: ContentDao,
    private val contentApi: ContentApi
) {

    // ── Observe ───────────────────────────────────────────────────────────────
    fun observeAll(): Flow<List<Content>> =
        contentDao.observeAll().map { it.map(ContentEntity::toDomain) }

    fun observeFavorites(): Flow<List<Content>> =
        contentDao.observeFavorites().map { it.map(ContentEntity::toDomain) }

    fun observeDownloads(): Flow<List<Content>> =
        contentDao.observeDownloads().map { it.map(ContentEntity::toDomain) }

    fun observeInProgress(): Flow<List<Content>> =
        contentDao.observeInProgress().map { it.map(ContentEntity::toDomain) }

    fun search(query: String, type: String = "", category: String = ""): Flow<List<Content>> =
        contentDao.search(query, type, category).map { it.map(ContentEntity::toDomain) }

    // ── Single item ───────────────────────────────────────────────────────────
    suspend fun getById(id: String): Content? =
        contentDao.getById(id)?.toDomain()

    // ── Network sync ──────────────────────────────────────────────────────────
    suspend fun syncManifest() {
        val manifest = contentApi.getManifest()
        val entities = manifest.contents.map { dto ->
            // Bestehendes lokales Item behalten (für isFavorite, isDownloaded, progress)
            val existing = contentDao.getById(dto.id)
            ContentEntity(
                id                 = dto.id,
                title              = dto.title,
                type               = dto.type,
                category           = dto.category,
                ageGroup           = dto.ageGroup,
                durationSeconds    = dto.durationSeconds,
                thumbnailUrl       = dto.thumbnailUrl,
                localThumbnailPath = existing?.localThumbnailPath,
                remoteUrl          = dto.remoteUrl,
                localPath          = existing?.localPath,
                description        = dto.description,
                tags               = dto.tags.joinToString(","),
                isFavorite         = existing?.isFavorite ?: false,
                isDownloaded       = existing?.isDownloaded ?: false,
                progress           = existing?.progress ?: 0f,
                version            = dto.version
            )
        }
        contentDao.upsertAll(entities)
    }

    // ── User actions ──────────────────────────────────────────────────────────
    suspend fun toggleFavorite(id: String) {
        val current = contentDao.getById(id) ?: return
        contentDao.setFavorite(id, !current.isFavorite)
    }

    suspend fun markDownloaded(id: String, localPath: String) {
        contentDao.setDownloaded(id, true, localPath)
    }

    suspend fun removeDownload(id: String) {
        contentDao.setDownloaded(id, false, null)
    }

    suspend fun updateProgress(id: String, progress: Float) {
        contentDao.updateProgress(id, progress.coerceIn(0f, 1f))
    }

    // ── Mapper ────────────────────────────────────────────────────────────────
    private fun ContentEntity.toDomain(): Content = Content(
        id                 = id,
        title              = title,
        type               = when (type.uppercase()) {
            "VIDEO" -> ContentType.VIDEO
            "AUDIO" -> ContentType.AUDIO
            "PDF"   -> ContentType.PDF
            "QUIZ"  -> ContentType.QUIZ
            else    -> ContentType.OTHER
        },
        category           = category,
        ageGroup           = ageGroup,
        durationSeconds    = durationSeconds,
        thumbnailUrl       = thumbnailUrl,
        localThumbnailPath = localThumbnailPath,
        remoteUrl          = remoteUrl,
        localPath          = localPath,
        description        = description,
        tags               = if (tags.isBlank()) emptyList() else tags.split(","),
        isFavorite         = isFavorite,
        isDownloaded       = isDownloaded,
        progress           = progress,
        version            = version
    )
}
