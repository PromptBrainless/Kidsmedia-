package de.fynn.kidsmedia.core.data

import de.fynn.kidsmedia.core.model.Content
import de.fynn.kidsmedia.core.model.ContentType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

data class HomeFeed(
    val featured:         List<Content>,
    val continueWatching: List<Content>,
    val newItems:         List<Content>,
    val recommended:      List<Content>,
    val byCategory:       Map<String, List<Content>>
)

class GetHomeFeedUseCase @Inject constructor(
    private val repository: ContentRepository
) {
    fun execute(): Flow<HomeFeed> =
        repository.observeAll().map { all ->
            val approved = all  // Repository liefert bereits gefiltert

            // Fortschritt 10–90%: aktiv gestartet, nicht fertig
            val inProgress = approved.filter { it.progress in 0.05f..0.95f }

            // Neueste nach Server-Version
            val newest = approved.sortedByDescending { it.version }.take(12)

            // Featured: bevorzuge Videos/Audio mit Thumbnail
            val featured = approved
                .filter { it.type == ContentType.VIDEO || it.type == ContentType.AUDIO }
                .take(5)
                .ifEmpty { approved.take(5) }

            // Empfohlen: nach Typ gemischt, zufällig rotiert
            val recommended = approved
                .shuffled()
                .take(10)

            // Kategorien-Gruppen
            val byCategory = approved
                .groupBy { it.category }
                .mapValues { (_, items) -> items.take(6) }

            HomeFeed(
                featured         = featured,
                continueWatching = inProgress,
                newItems         = newest,
                recommended      = recommended,
                byCategory       = byCategory
            )
        }
}
