package de.fynn.kidsmedia.core.data

import android.content.Context
import androidx.work.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import javax.inject.Inject
import javax.inject.Singleton

// ── Download-Status ───────────────────────────────────────────────────────────
sealed class DownloadStatus {
    object Idle                           : DownloadStatus()
    data class Downloading(val progress: Int) : DownloadStatus()
    data class Done(val localPath: String): DownloadStatus()
    data class Failed(val reason: String) : DownloadStatus()
}

// ── DownloadManager ───────────────────────────────────────────────────────────
@Singleton
class KidsMediaDownloadManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: ContentRepository
) {
    /**
     * Startet den Download eines Inhalts.
     * Gibt einen Flow mit DownloadStatus-Updates zurück.
     */
    fun download(contentId: String, remoteUrl: String, fileName: String): Flow<DownloadStatus> = flow {
        emit(DownloadStatus.Downloading(0))
        try {
            val destDir  = File(context.filesDir, "media").also { it.mkdirs() }
            val destFile = File(destDir, fileName)

            val conn = URL(remoteUrl).openConnection() as HttpURLConnection
            conn.connect()
            val totalBytes = conn.contentLength.toLong()
            var downloaded  = 0L

            conn.inputStream.use { input ->
                FileOutputStream(destFile).use { output ->
                    val buffer = ByteArray(8 * 1024)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        downloaded += bytesRead
                        if (totalBytes > 0) {
                            val pct = ((downloaded * 100) / totalBytes).toInt()
                            emit(DownloadStatus.Downloading(pct))
                        }
                    }
                }
            }
            conn.disconnect()

            // Persistiere lokalen Pfad in der DB
            repository.markDownloaded(contentId, destFile.absolutePath)
            emit(DownloadStatus.Done(destFile.absolutePath))

        } catch (e: Exception) {
            emit(DownloadStatus.Failed(e.message ?: "Unbekannter Fehler"))
        }
    }

    /**
     * Löscht einen lokalen Download und setzt den DB-Eintrag zurück.
     */
    suspend fun deleteDownload(contentId: String, localPath: String) {
        File(localPath).takeIf { it.exists() }?.delete()
        repository.removeDownload(contentId)
    }

    /**
     * Gibt den belegten Speicherplatz (Bytes) für alle Downloads zurück.
     */
    fun totalDownloadSizeBytes(): Long {
        val dir = File(context.filesDir, "media")
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }
}

// ── WorkManager Worker (für Hintergrund-Downloads) ────────────────────────────
class ContentDownloadWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val contentId  = inputData.getString(KEY_CONTENT_ID)  ?: return Result.failure()
        val remoteUrl  = inputData.getString(KEY_REMOTE_URL)   ?: return Result.failure()
        val fileName   = inputData.getString(KEY_FILE_NAME)    ?: return Result.failure()

        return try {
            val destDir  = File(applicationContext.filesDir, "media").also { it.mkdirs() }
            val destFile = File(destDir, fileName)

            val conn = URL(remoteUrl).openConnection() as HttpURLConnection
            conn.connect()

            conn.inputStream.use { input ->
                FileOutputStream(destFile).use { output ->
                    val buffer = ByteArray(8 * 1024)
                    var bytesRead: Int
                    var downloaded = 0L
                    val total = conn.contentLength.toLong()

                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        downloaded += bytesRead
                        if (total > 0) {
                            val pct = ((downloaded * 100) / total).toInt()
                            setProgress(workDataOf(KEY_PROGRESS to pct))
                        }
                    }
                }
            }
            conn.disconnect()
            Result.success(workDataOf(KEY_LOCAL_PATH to destFile.absolutePath))
        } catch (e: Exception) {
            Result.failure(workDataOf(KEY_ERROR to (e.message ?: "Download fehlgeschlagen")))
        }
    }

    companion object {
        const val KEY_CONTENT_ID = "content_id"
        const val KEY_REMOTE_URL = "remote_url"
        const val KEY_FILE_NAME  = "file_name"
        const val KEY_PROGRESS   = "progress"
        const val KEY_LOCAL_PATH = "local_path"
        const val KEY_ERROR      = "error"

        fun buildRequest(contentId: String, remoteUrl: String, fileName: String): OneTimeWorkRequest =
            OneTimeWorkRequestBuilder<ContentDownloadWorker>()
                .setInputData(
                    workDataOf(
                        KEY_CONTENT_ID to contentId,
                        KEY_REMOTE_URL to remoteUrl,
                        KEY_FILE_NAME  to fileName
                    )
                )
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .addTag("download_$contentId")
                .build()
    }
}
