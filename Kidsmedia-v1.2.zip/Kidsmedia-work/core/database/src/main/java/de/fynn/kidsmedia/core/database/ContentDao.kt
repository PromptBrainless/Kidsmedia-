package de.fynn.kidsmedia.core.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ContentDao {

    // ── Reads ─────────────────────────────────────────────────────────────────
    @Query("SELECT * FROM content WHERE id = :id")
    suspend fun getById(id: String): ContentEntity?

    @Query("SELECT * FROM content ORDER BY version DESC")
    fun observeAll(): Flow<List<ContentEntity>>

    @Query("SELECT * FROM content WHERE isFavorite = 1 ORDER BY title ASC")
    fun observeFavorites(): Flow<List<ContentEntity>>

    @Query("SELECT * FROM content WHERE isDownloaded = 1 ORDER BY title ASC")
    fun observeDownloads(): Flow<List<ContentEntity>>

    @Query("SELECT * FROM content WHERE progress > 0.05 AND progress < 0.95")
    fun observeInProgress(): Flow<List<ContentEntity>>

    @Query("""
        SELECT * FROM content
        WHERE (:query = '' OR title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%')
        AND   (:type  = '' OR type = :type)
        AND   (:category = '' OR category = :category)
        ORDER BY version DESC
    """)
    fun search(query: String, type: String, category: String): Flow<List<ContentEntity>>

    // ── Writes ────────────────────────────────────────────────────────────────
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ContentEntity>)

    @Query("UPDATE content SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: String, fav: Boolean)

    @Query("UPDATE content SET isDownloaded = :dl, localPath = :path WHERE id = :id")
    suspend fun setDownloaded(id: String, dl: Boolean, path: String?)

    @Query("UPDATE content SET progress = :progress WHERE id = :id")
    suspend fun updateProgress(id: String, progress: Float)

    @Query("DELETE FROM content WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM content")
    suspend fun deleteAll()
}
