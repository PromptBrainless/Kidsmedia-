package de.fynn.kidsmedia.core.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Palette ──────────────────────────────────────────────────────────────────
val IndigoBase    = Color(0xFF4F46E5)
val IndigoDark    = Color(0xFF3730A3)
val IndigoLight   = Color(0xFF818CF8)
val TealAccent    = Color(0xFF14B8A6)
val EmeraldAccent = Color(0xFF10B981)
val VioletAccent  = Color(0xFF7C3AED)
val AmberAccent   = Color(0xFFF59E0B)
val RoseAlert     = Color(0xFFF43F5E)

val Surface950    = Color(0xFF020617)
val Surface900    = Color(0xFF0F172A)
val Surface800    = Color(0xFF1E293B)
val Surface700    = Color(0xFF334155)
val OnSurface100  = Color(0xFFF1F5F9)
val OnSurface400  = Color(0xFF94A3B8)

private val DarkColors = darkColorScheme(
    primary          = IndigoBase,
    onPrimary        = Color.White,
    primaryContainer = IndigoDark,
    secondary        = TealAccent,
    onSecondary      = Color.White,
    tertiary         = VioletAccent,
    background       = Surface950,
    onBackground     = OnSurface100,
    surface          = Surface900,
    onSurface        = OnSurface100,
    surfaceVariant   = Surface800,
    onSurfaceVariant = OnSurface400,
    error            = RoseAlert,
    outline          = Surface700
)

private val LightColors = lightColorScheme(
    primary          = IndigoDark,
    onPrimary        = Color.White,
    primaryContainer = IndigoLight,
    secondary        = TealAccent,
    onSecondary      = Color.White,
    tertiary         = VioletAccent,
    background       = Color(0xFFF8FAFC),
    onBackground     = Color(0xFF0F172A),
    surface          = Color.White,
    onSurface        = Color(0xFF1E293B),
    surfaceVariant   = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF64748B),
    error            = RoseAlert,
    outline          = Color(0xFFCBD5E1)
)

@Composable
fun KidsMediaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography  = KidsMediaTypography,
        content     = content
    )
}
